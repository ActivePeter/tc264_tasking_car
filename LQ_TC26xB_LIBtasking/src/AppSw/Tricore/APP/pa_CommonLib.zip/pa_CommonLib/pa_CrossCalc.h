#ifndef _pa_CrossCalc_H
#define _pa_CrossCalc_H

float getMotorRotationValueByErr(char err);

#endif