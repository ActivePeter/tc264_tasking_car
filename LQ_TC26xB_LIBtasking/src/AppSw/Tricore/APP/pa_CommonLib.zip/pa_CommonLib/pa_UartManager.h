#ifndef __pa_UartManager_H_
#define __pa_UartManager_H_


extern "C"
{
    #include "pa_MainApp.h"
}
void checkUartData();

#endif