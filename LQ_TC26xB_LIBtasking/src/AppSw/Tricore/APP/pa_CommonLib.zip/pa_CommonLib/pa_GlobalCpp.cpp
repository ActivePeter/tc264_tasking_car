#include "pa_GlobalCpp.h"

pa_GlobalCpp::pa_GlobalCpp(){

}

