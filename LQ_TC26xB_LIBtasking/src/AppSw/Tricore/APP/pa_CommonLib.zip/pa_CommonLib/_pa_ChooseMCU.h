//在这个文件中进行平台宏定义。以此来使库兼容不同平台
#ifndef _pa_ChooseMCU_H

#define LQ_TC264

#endif